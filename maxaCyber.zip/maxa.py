#!/usr/bin/env python3
"""
@maxaCyber MASTER LAUNCHER v1.0
Central Command Dashboard for all MAXA Cyber Security Tools
"""

import sys
import os
import subprocess

GREEN = '\033[92m'
CYAN = '\033[96m'
YELLOW = '\033[93m'
END = '\033[0m'
BOLD = '\033[1m'

BANNER = f"""{CYAN}{BOLD}
   ██████╗  ███╗   ███╗██████╗  ██╗  ██╗██████╗ ██╗██████╗ ███████╗██████╗ 
  ██╔════╝  ████╗ ████║██╔══██╗ ██║  ██║██╔════╝██║██╔══██╗██╔════╝██╔══██╗
  ██║  ███╗ ██╔████╔██║███████║ ███████║██║     ██║██████╔╝█████╗  ██████╔╝
  ██║   ██║ ██║╚██╔╝██║██╔══██║ ██╔══██║██║     ██║██╔══██╗██╔══╝  ██╔══██╗
  ╚██████╔╝ ██║ ╚═╝ ██║██║  ██║ ██║  ██║╚██████╗██║██████╔╝███████╗██║  ██║
   ╚═════╝  ╚═╝     ╚═╝╚═╝  ╚═╝ ╚═╝  ╚═╝ ╚═════╝╚═╝╚═════╝ ╚══════╝╚═╝  ╚═╝
{END}{YELLOW}                    ALL-IN-ONE CYBERSECURITY DASHBOARD{END}
"""

TOOLS = {
    "1": ("MAXA Mega Framework (5-in-1 Suite)", "maxa_cyber_framework.py"),
    "2": ("CyberPulse Recon & Port Scanner", "cyber_pulse.py"),
    "3": ("LogSentinel Intrusion Detector", "log_sentinel.py"),
    "4": ("Web Directory Fuzzer", "dir_fuzzer.py"),
    "5": ("PassGuard Pro Password Analyzer", "pass_guard.py"),
    "6": ("Subdomain Takeover Auditor", "sub_takeover_checker.py"),
    "7": ("API Key Leak Scanner", "api_key_sentinel.py"),
    "8": ("NetSniffer Packet Analyzer", "net_sniffer.py"),
    "9": ("SmartUnzip Zero-Deduplication Engine", "smart_unzip.py"),
    "10": ("Auto Dependency Installer", "all_install.py"),
}

def main():
    print(BANNER)
    print(f"{BOLD}O'rnashgan papka:{END} {os.getcwd()}\n")
    print(f"{BOLD}Mavjud Kiber-Toollar ro'yxati:{END}")
    for num, (name, script) in TOOLS.items():
        print(f"  [{num}] {name:<42} ({script})")
    print("  [0] Chiqish\n")

    choice = input(f"{BOLD}Ishga tushirish uchun raqamni kiriting [1-10]: {END}").strip()
    if choice in TOOLS:
        script = TOOLS[choice][1]
        print(f"\n{GREEN}[+] Ishga tushirilmoqda: {script}{END}\n")
        subprocess.run([sys.executable, script])
    else:
        print("Chiqildi.")

if __name__ == "__main__":
    main()
